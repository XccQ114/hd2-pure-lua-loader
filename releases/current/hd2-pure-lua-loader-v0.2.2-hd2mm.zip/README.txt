HD2 Pure-Lua Mod Loader 0.2.2
=====================================

What this is
------------
A pure-Lua mod loader for HELLDIVERS 2 (Steam build 25988413). It installs a single file,
data\9ba626afa44a3aa3.patch_0, which the engine reads at startup. That patch contains a Lua
resource called `boot`, and the loader uses it to host pure-Lua mods.

No DLL, no code signature, no anti-cheat interaction, no Bingus Shared Loader.

Install
-------
Through HD2MM: import this ZIP, enable it, press Deploy. Done.
Manually: copy the three files from data\ into <game>\data\ (the two sidecars are 0 bytes
but must exist).

!!! ONE BOOT SLOT ONLY !!!
This mod occupies data\9ba626afa44a3aa3.patch_0. Do not enable it together with another mod
that ships the same file (Bingus Shared Loader, ArmoryForge menu mods, other boot-level mods).
Last deployed wins; the other one silently stops working.

Installing a Lua mod
--------------------
    <game>\mods\<name>\main.lua      your mod
    <game>\mods\mods.txt             one directory name per line

Then launch through Steam (steam://rungameid/553850) and read <game>\mods\loader.log.
Expected first lines:

    === hd2 pure-lua loader start ===
    [host] update/shutdown hooked (prev_update=nil, prev_shutdown=nil)
    [host] init/render hooked (prev_init=nil, prev_render=nil)
    [boot] loaded N mod(s)

Limits
------
No FFI: cannot read or write game memory, cannot change damage/ammo/cooldowns.
Unit positions are unreadable on this build (world_position is always 0,0,0).
Works on build 25988413 only; a game update invalidates addresses.

Rollback
--------
In HD2MM: disable/uninstall and Deploy again. Manually: restore the patch_0 you backed up.

Source, docs, crash-point table: https://github.com/XccQ114/hd2-pure-lua-loader
